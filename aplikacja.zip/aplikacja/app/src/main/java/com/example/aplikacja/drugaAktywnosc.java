package com.example.aplikacja;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class drugaAktywnosc extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_druga_aktywnosc);

        Intent intent = getIntent();
        int number1 = intent.getIntExtra("test",0);
        int number2 = intent.getIntExtra("Test2",0);

        TextView textView1 = (TextView) findViewById(R.id.textView1);
        TextView textView2 = (TextView) findViewById(R.id.textView2);

        int sumaliczb = number1+number2;

        textView1.setText("Suma liczb wynosi " + sumaliczb);


        Button button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wybieramA();

            }
        });

        Button button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wybieramB();
//                wybieramC();
            }


        });


    }
    public void wybieramA(){
        Intent intent = getIntent();
        int number1 = intent.getIntExtra("test",0);
        int number2 = intent.getIntExtra("Test2",0);
        int wartosc = 0;
        int wartosc2 =0;

        if(number1>=number2){
            wartosc = number2;
            wartosc2 = number1;
            int sumawartosci=0;
            for (int i=wartosc; i <= wartosc2; i++){
                if(i%3==0){
                    sumawartosci = i + sumawartosci;

                };

            };
                 Intent intentA = new Intent(this, MainActivity.class);
                    intentA.putExtra("nowy", sumawartosci);
                    startActivity(intentA);
        }
        else{wartosc = number1;
            wartosc2 = number2;
            int sumawartosci=0;
            for (int i=wartosc; i <= wartosc2; i++){
                if(i%3==0){
                    sumawartosci = i + sumawartosci;

                };

            };
            Intent intentA = new Intent(this, MainActivity.class);
            intentA.putExtra("nowy", sumawartosci);
            startActivity(intentA);
        }
    };


    public void wybieramB(){
        Intent intent = getIntent();
        int number1 = intent.getIntExtra("test",0);
        int number2 = intent.getIntExtra("Test2",0);
        int wartosc = 0;
        int wartosc2 =0;

        if(number1>=number2){
            wartosc = number2;
            wartosc2 = number1;
            int sumawartosci=(wartosc+wartosc2)*(wartosc+wartosc2);
            int wartoscmin = wartosc+wartosc2;
            int min = 0;
            int max = 0;
            for (int i=sumawartosci; i > wartoscmin; i--) {
                if (i%i == 0 && i%2 != 0) {
                    min = i;
                }
            };
            int widok = R.color.red;
            Intent intentB = new Intent(this, MainActivity.class);
            intentB.putExtra("nowy", min);
            intentB.putExtra("nowy1",widok);
            startActivity(intentB);

        }
        else{wartosc = number1;
            wartosc2 = number2;
            int sumawartosci= (wartosc+wartosc2)*(wartosc+wartosc2);
            int wartoscmin = wartosc+wartosc2;
            int min =0;
            int max = 0;
            for (int i=sumawartosci; i > wartoscmin; i--) {
                if (i % i == 0 && i%2 != 0) {
                    min = i;
                }
            }
            int widok = R.color.red;
            Intent intentB = new Intent(this, MainActivity.class);
            intentB.putExtra("nowy", min);
            intentB.putExtra("nowy1",widok);
            startActivity(intentB);

        }
    };




}
