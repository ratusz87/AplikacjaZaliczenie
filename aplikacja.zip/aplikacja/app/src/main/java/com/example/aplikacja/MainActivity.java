package com.example.aplikacja;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
//    public static final String EXTRA_Number_1 = "com.example.aplikacja.Extra_Number_1";
//    public static final String EXTRA_Number_2 = "com.example.aplikacja.Extra_Number_2";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent2 = getIntent();
        int numer4 = intent2.getIntExtra("nowy",0);
        TextView textView3 = (TextView) findViewById(R.id.textViewA);
        textView3.setText(""+ numer4);

        int numer5 = intent2.getIntExtra("nowy1",0);
        textView3.setBackgroundResource(numer5);

        Button button = (Button) findViewById(R.id.button);
         button.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 openActivity2();

             }
         });

           }

           public void openActivity2(){
               EditText editText1 = (EditText) findViewById(R.id.editText1);
                int number1 =Integer.parseInt(editText1.getText().toString());
               EditText editText2 = (EditText) findViewById(R.id.editText2);
                int number2 =Integer.parseInt(editText2.getText().toString());
//
               Intent intent = new Intent(this, drugaAktywnosc.class);
               intent.putExtra("test",number1);
               intent.putExtra("Test2",number2);


               startActivity(intent);

           }

}
